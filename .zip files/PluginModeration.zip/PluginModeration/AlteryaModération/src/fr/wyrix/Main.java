package fr.wyrix;

import java.util.Collections;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import fr.wyrix.commands.CommandGm;
import fr.wyrix.commands.CommandStaff;
import fr.wyrix.commands.Commands;
import fr.wyrix.gui.GuiManager;
import fr.wyrix.listeners.PlayerListener;
import fr.wyrix.tools.DCommand;


public class Main extends JavaPlugin implements Listener{
	
	private static Main instance;
	private GuiManager guiManager;
	
	
	@Override
	public void onEnable() {
		instance = this;
		System.out.println("Le Plugin Mod�ration viens de s'allumer !");
	
		this.guiManager = new GuiManager(this);
		this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
		this.getServer().getPluginManager().registerEvents(this, this);
		
		//new DCommand("vanish", "/vanish", "Vanish player", null, Collections.singletonList(""), new CommandStaff(),this);
		new DCommand("Vanish", "/vanish", "Passe en mode Invicible", "use.vanish", Collections.singletonList(""), new CommandStaff(), this);
		new DCommand("Admin", "/admin", "Mode Mod�rateur", "use.adminmod", Collections.singletonList(""), new Commands(), this);
		new DCommand("Alert", "/alert", "Annonce un message � tous", "use.alert", Collections.singletonList(""), new Commands(), this);
		new DCommand("Rb", "/rb", "Restart le serveur", "use.reboot", Collections.singletonList(""), new Commands(), this);
		new DCommand("GM", "/gm", "Change de mode Rapidement", "use.fastgm", Collections.singletonList(""), new CommandGm(), this);
		new DCommand("ClearChat", "/clearchat", "Nettoie le Chat", "use.clearchat", Collections.singletonList(""), new Commands(), this);
	}
	
	
	@Override
	public void onDisable() {
		System.out.println("Le Plugin Mod�ration viens de s'eteindre !");
	}
	
    public GuiManager getGuiManager() {
		return guiManager;
	}

	public static Main getInstance() {
        return instance;
    }
}


