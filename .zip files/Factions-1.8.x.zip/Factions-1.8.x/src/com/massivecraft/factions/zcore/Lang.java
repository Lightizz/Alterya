package com.massivecraft.factions.zcore;

public class Lang
{
	public static final String permForbidden = "<b>You don't have permission to %s.";
	public static final String permDoThat = "do that";
	
	public static final String commandSenderMustBePlayer = "<b>This command can only be used by ingame players.";
	public static final String commandToFewArgs = "<b>Too few arguments. <i>Use like this:";
	public static final String commandToManyArgs = "<b>Strange argument \"<p>%s<b>\". <i>Use the command like this:";
}
